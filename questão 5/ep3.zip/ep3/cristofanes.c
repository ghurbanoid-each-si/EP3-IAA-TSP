// COMPUTER GEEK - compgeek.co.in

// Write a program for Christofides Algorithm

 

#include <stdio.h>

#include <stdlib.h>

#include <stdbool.h>

 

#define INF 999999

 

// Structure to represent an edge in the graph

struct Edge {

    int u, v, weight;

};

 

// Structure to represent a subset for Union-Find

struct Subset {

    int parent;

    int rank;

};

 

// Function to find the parent of a node in Union-Find

int find(struct Subset subsets[], int i) {

    if (subsets[i].parent != i)

        subsets[i].parent = find(subsets, subsets[i].parent);

    return subsets[i].parent;

}

 

// Function to perform union of two sets in Union-Find

void Union(struct Subset subsets[], int x, int y) {

    int rootX = find(subsets, x);

    int rootY = find(subsets, y);

   

    if (subsets[rootX].rank < subsets[rootY].rank)

        subsets[rootX].parent = rootY;

    else if (subsets[rootX].rank > subsets[rootY].rank)

        subsets[rootY].parent = rootX;

    else {

        subsets[rootY].parent = rootX;

        subsets[rootX].rank++;

    }

}

 

// Function to compare two edges based on their weight for sorting

int compareEdges(const void *a, const void *b) {

    struct Edge *edgeA = (struct Edge *)a;

    struct Edge *edgeB = (struct Edge *)b;

    return edgeA->weight - edgeB->weight;

}

 

// Kruskal’s algorithm to find the Minimum Spanning Tree (MST)

void kruskalMST(int n, int edgesCount, struct Edge edges[], int mst[][n]) {

    qsort(edges, edgesCount, sizeof(edges[0]), compareEdges);

   

    struct Subset *subsets = (struct Subset *)malloc(n * sizeof(struct Subset));

    for (int v = 0; v < n; ++v) {

        subsets[v].parent = v;

        subsets[v].rank = 0;

    }

 

    int edgesInMST = 0, i = 0;

    while (edgesInMST < n - 1 && i < edgesCount) {

        struct Edge nextEdge = edges[i++];

        int x = find(subsets, nextEdge.u);

        int y = find(subsets, nextEdge.v);

 

        if (x != y) {

            mst[nextEdge.u][nextEdge.v] = nextEdge.weight;

            mst[nextEdge.v][nextEdge.u] = nextEdge.weight;

            Union(subsets, x, y);

            edgesInMST++;

        }

    }

 

    free(subsets);

}

 

// Function to find odd-degree vertices from the MST

void findOddDegreeVertices(int n, int mst[][n], int oddDegreeVertices[], int *oddCount) {

    *oddCount = 0;

    for (int i = 0; i < n; i++) {

        int degree = 0;

        for (int j = 0; j < n; j++) {

            if (mst[i][j] != 0)

                degree++;

        }

        if (degree % 2 == 1) {

            oddDegreeVertices[*oddCount] = i;

            (*oddCount)++;

        }

    }

}

 

// Function to generate a Minimum Perfect Matching (using greedy approach)

void minPerfectMatching(int n, int oddDegreeVertices[], int oddCount, int dist[][n], int mst[][n]) {

    bool matched[oddCount];

    for (int i = 0; i < oddCount; i++)

        matched[i] = false;

 

    for (int i = 0; i < oddCount; i++) {

        if (!matched[i]) {

            int minDist = INF, minIndex = -1;

            for (int j = i + 1; j < oddCount; j++) {

                if (!matched[j] && dist[oddDegreeVertices[i]][oddDegreeVertices[j]] < minDist) {

                    minDist = dist[oddDegreeVertices[i]][oddDegreeVertices[j]];

                    minIndex = j;

                }

            }

            mst[oddDegreeVertices[i]][oddDegreeVertices[minIndex]] = dist[oddDegreeVertices[i]][oddDegreeVertices[minIndex]];

            mst[oddDegreeVertices[minIndex]][oddDegreeVertices[i]] = dist[oddDegreeVertices[minIndex]][oddDegreeVertices[i]];

            matched[i] = true;

            matched[minIndex] = true;

        }

    }

}

 

// Function to perform DFS to find Eulerian Tour

void dfs(int v, int n, int mst[][n], bool visited[], int path[], int *pathIndex) {

    visited[v] = true;

    path[(*pathIndex)++] = v;

    for (int i = 0; i < n; i++) {

        if (mst[v][i] != 0 && !visited[i]) {

            dfs(i, n, mst, visited, path, pathIndex);

        }

    }

}

 

// Function to calculate the Hamiltonian Tour and its cost

int calculateHamiltonianTour(int n, int dist[][n], int path[], int pathLength) {

    bool visited[n];

    for (int i = 0; i < n; i++)

        visited[i] = false;

 

    int totalCost = 0;

    int tour[n], tourIndex = 0;

 

    for (int i = 0; i < pathLength; i++) {

        if (!visited[path[i]]) {

            tour[tourIndex++] = path[i];

            visited[path[i]] = true;

        }

    }

 

    tour[tourIndex] = tour[0];  // Complete the tour by returning to the start

 

    printf("Hamiltonian Tour: ");

    for (int i = 0; i <= tourIndex; i++)
    
        printf("%d ", (tour[i] + 1)); // Printing 1-based city index

    printf("\n");

 

    // Calculate the total cost of the Hamiltonian tour

    for (int i = 0; i < tourIndex; i++) {

        totalCost += dist[tour[i]][tour[i + 1]];

    }

 

    return totalCost;

}

 

int main() {

    int n;

    printf("Enter the number of cities: ");

    scanf("%d", &n);

 

    int dist[n][n];

    printf("Enter the distance matrix:\n");

    for (int i = 0; i < n; i++) {

        for (int j = 0; j < n; j++) {

            scanf("%d", &dist[i][j]);

        }

    }

 

    int edgesCount = 0;

    struct Edge edges[n * (n - 1) / 2];

 

    // Create an edge list from the distance matrix

    for (int i = 0; i < n; i++) {

        for (int j = i + 1; j < n; j++) {

            edges[edgesCount].u = i;

            edges[edgesCount].v = j;

            edges[edgesCount].weight = dist[i][j];

            edgesCount++;

        }

    }

 

    // Kruskal’s algorithm to generate the Minimum Spanning Tree

    int mst[n][n];

    for (int i = 0; i < n; i++)

        for (int j = 0; j < n; j++)

            mst[i][j] = 0;

 

    kruskalMST(n, edgesCount, edges, mst);

 

    // Find odd-degree vertices

    int oddDegreeVertices[n], oddCount;

    findOddDegreeVertices(n, mst, oddDegreeVertices, &oddCount);

 

    // Generate minimum perfect matching

    minPerfectMatching(n, oddDegreeVertices, oddCount, dist, mst);

 

    // Find Eulerian Tour using DFS

    bool visited[n];

    for (int i = 0; i < n; i++)

        visited[i] = false;

 

    int path[2 * n], pathIndex = 0;

    dfs(0, n, mst, visited, path, &pathIndex);

 

    // Calculate the Hamiltonian Tour and its total cost

    int totalCost = calculateHamiltonianTour(n, dist, path, pathIndex);

    printf("Total Cost of the Hamiltonian Tour: %d\n", totalCost);

 

    return 0;

}