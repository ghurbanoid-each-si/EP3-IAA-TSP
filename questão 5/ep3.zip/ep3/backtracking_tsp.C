#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

#define MAX_CITIES 10  // Adjust as needed

int n; // Number of cities
int graph[MAX_CITIES][MAX_CITIES];
bool visited[MAX_CITIES];
int bestPath[MAX_CITIES + 1];
int currentPath[MAX_CITIES + 1];
int minCost = INT_MAX;

// Backtracking function to find minimum cost tour
void tspBacktrack(int city, int count, int cost) {
    // If all cities are visited, check return to start
    if (count == n && graph[city][0] > 0) {
        int totalCost = cost + graph[city][0];
        if (totalCost < minCost) {
            minCost = totalCost;
            for (int i = 0; i < n; i++)
                bestPath[i] = currentPath[i];
            bestPath[n] = 0; // Return to start
        }
        return;
    }

    // Try next cities
    for (int next = 0; next < n; next++) {
        if (!visited[next] && graph[city][next] > 0) {
            visited[next] = true;
            currentPath[count] = next;
            tspBacktrack(next, count + 1, cost + graph[city][next]);
            visited[next] = false; // Backtrack
        }
    }
}

int main() {
    printf("Enter number of cities (max %d): ", MAX_CITIES);
    if (scanf("%d", &n) != 1 || n <= 1 || n > MAX_CITIES) {
        printf("Invalid number of cities.\n");
        return 1;
    }

    printf("Enter adjacency matrix (%d x %d):\n", n, n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (scanf("%d", &graph[i][j]) != 1 || graph[i][j] < 0) {
                printf("Invalid input. Distances must be non-negative.\n");
                return 1;
            }
        }
    }

    // Initialize visited array
    for (int i = 0; i < n; i++)
        visited[i] = false;

    visited[0] = true; // Start from city 0
    currentPath[0] = 0;

    tspBacktrack(0, 1, 0);

    if (minCost == INT_MAX) {
        printf("No Hamiltonian cycle found.\n");
    } else {
        printf("Minimum cost: %d\n", minCost);
        printf("Path: ");
        for (int i = 0; i <= n; i++)
            printf("%d ", bestPath[i]);
        printf("\n");
    }

    return 0;
}
